# Smart Student Helpdesk — upgraded project

A Flask + SQLite college helpdesk prototype with a student portal, staff dashboard, academic records, optional AI/email/weather integrations and the original themed chatbot UI.

## Included features

### Public helpdesk
- Existing keyword/FAQ chatbot for admissions, fees, exams, timetables and college events.
- Existing course/semester timetable and exam demo data.
- Optional Google Gemini fallback for natural-language questions when no predefined answer matches.
- Student records are never returned to public chatbot visitors.

### Student portal
- Student registration using a Student ID already present in the college database.
- Email-based password reset link (requires configured Resend sender/API key).
- Password-hashed student login and logout.
- Attendance percentage and Present/Absent/Late totals.
- Fee summary, published results, notices, course assignments and notifications.
- Complaint submission and complaint status tracking.

### Staff/admin portal
- Staff login and student directory/search/profile.
- Add student records.
- Publish notices and announcements.
- Record attendance and subject-wise results.
- Upload assignments with course targeting and due dates.
- Review complaints and update their status.

### Optional integrations
- Gemini API: AI chatbot fallback (`GEMINI_API_KEY`).
- Resend API: transactional email (`RESEND_API_KEY`, verified sender required).
- Open-Meteo: weather JSON endpoint (`/weather`).
- Local assignment uploads are included. Cloud storage, online payment and SMS are documented extension points and are not active integrations.

## Requirements
- Python 3.10+
- Flask 3.x
- Internet only for optional APIs

## Quick start (Windows)
1. Extract the ZIP and open its folder in VS Code.
2. Create a virtual environment: `python -m venv .venv`
3. Activate it: `.venv\\Scripts\\activate`
4. Install dependencies: `pip install -r requirements.txt`
5. Copy `.env.example` to `.env` and set a strong `SECRET_KEY` and `ADMIN_PASSWORD` before use. The included `python-dotenv` dependency loads `.env` automatically for local development.
6. Run: `python app.py`
7. Open `http://127.0.0.1:5000`.

## Quick start (macOS/Linux)
1. `python3 -m venv .venv`
2. `source .venv/bin/activate`
3. `pip install -r requirements.txt`
4. Copy `.env.example` to `.env`; export the variables or configure your deployment secrets.
5. `python app.py`

The `helpdesk.db` SQLite database and new tables are created automatically. Existing database records are retained; new tables are added using `CREATE TABLE IF NOT EXISTS`.

## Demo staff account
- Username: `admin`
- Password: `admin123`

This default is for local demonstration only. Set `ADMIN_USERNAME` and `ADMIN_PASSWORD` before first database creation in a fresh install. If the demo admin already exists in an existing database, change its password in the database or create a proper admin-management workflow before deployment.

## Demo student records
- STU1001
- STU1002
- STU1003

Student portal registration is allowed only for Student IDs already present in the `students` table. Students choose their own password at registration. Demo personal data is fictional and must be replaced with authorised college data before real use.

## Main routes

| Route | Purpose | Access |
|---|---|---|
| `/` | Public helpdesk/chatbot | Public |
| `/api/chat` | Chatbot JSON endpoint | Public; private record lookup blocked |
| `/login` | Staff login | Public |
| `/dashboard` | Student directory and admin tools | Staff |
| `/student/register` | Student account registration | Public; existing Student ID required |
| `/student/login` | Student login | Public |
| `/student/forgot-password` | Request email reset link | Public |
| `/student/portal` | Attendance, fees, results, notices, assignments, complaints | Student |
| `/weather` | Open-Meteo current weather JSON | Public |
| `/health` | Health check | Public |

## Database tables

Existing: `students`, `faqs`, `admins`, `class_schedule`, `exam_schedule`, `college_events`.

Added: `student_accounts`, `attendance`, `notices`, `assignments`, `results`, `complaints`, `notifications`, `chat_history`.

## API configuration

Read [API_SETUP.md](API_SETUP.md) for obtaining keys, setup, use cases, limitations and services intentionally left unconnected. `.env.example` lists all supported environment variables.

## Security and production checklist

This remains an educational prototype, not a production-ready student information system. Before real college use:
- Replace demo credentials and use a long random `SECRET_KEY`.
- Set `COOKIE_SECURE=1` behind HTTPS and keep `FLASK_DEBUG=0`.
- Add CSRF protection to every form, login throttling, audit logs, account recovery with verified email, backups and monitoring.
- Add role-based staff accounts instead of the single demo staff login.
- Review privacy, consent, retention and access policies with the college.
- Restrict upload access, scan files for malware, use private cloud storage for production and back up uploads.
- Add pagination and database indexes for larger datasets; consider PostgreSQL for multi-user production workloads.
- Replace fictional timetable, event and exam records with approved current information.
- Do not store payment-card data or request UPI PINs/OTPs. Use a provider-hosted checkout only after institution approval.

## Testing
Run `python -m unittest discover -s tests` from the project directory. The tests exercise the Flask app's public routes and basic student/admin workflows.
