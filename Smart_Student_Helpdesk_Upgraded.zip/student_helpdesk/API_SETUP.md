# API setup and integration guide

This project works locally without paid APIs. External services are optional and are only activated when their environment variables are configured.

## 1. Google Gemini API — optional AI chatbot

- Purpose: natural-language answers when the existing FAQ/intent matcher has no answer.
- Get a key: https://aistudio.google.com/app/apikey
- Pricing/limits: https://ai.google.dev/gemini-api/docs/pricing
- Set `GEMINI_API_KEY` and optionally `GEMINI_MODEL` in your environment (or your local `.env` loader/deployment secret store).
- Default model configured: `gemini-2.5-flash`; verify current availability in Google AI Studio.
- The key is read only by Flask in `app.py`; never put it in HTML or JavaScript.
- The prompt warns the model not to invent college-specific data. For authoritative answers, extend the backend to retrieve approved FAQ, notice, timetable and policy records and pass only the relevant verified content to the model.
- Gemini is not called for staff-only Student ID lookup. Private records are not automatically sent to the AI provider.
- Review Google's current free-tier, privacy and data-use terms before sending any student/personal information. Do not send sensitive records to a generative model.

## 2. Resend API — optional transactional email

- Purpose: account-created confirmation and future password-reset/complaint emails.
- Docs: https://resend.com/docs and https://resend.com/pricing
- Verify a sender domain in Resend, then set `RESEND_API_KEY` and `RESEND_FROM_EMAIL`.
- `send_email()` in `app.py` calls Resend server-side. If credentials are absent, the app continues without sending mail.
- Free-plan limits and sender verification requirements can change; check Resend's current pricing.

## 3. Open-Meteo — optional weather widget/API

- Purpose: optional weather information for outdoor campus activities.
- Docs: https://open-meteo.com/en/docs
- No API key is required for eligible non-commercial use under its current terms.
- Endpoint: `/weather?lat=19.0760&lon=72.8777` (coordinates are examples only; change them to the campus coordinates).
- The endpoint returns current temperature, humidity, precipitation and weather code. The UI does not call it automatically.

## 4. Cloud storage — not connected by default

Assignments currently upload to the local `uploads/` folder (10 MB maximum). For production or multiple app servers, connect an object-storage provider such as Cloudinary, Supabase Storage or Amazon S3. Create a private bucket, restrict file types/size, use signed downloads, and store only the object key in SQLite. Do not make student submissions public.

## 5. Payment gateway — not connected by default

No payment API is enabled. This is deliberate: payment processing requires a verified merchant account, institution approval, webhook signature verification and secure reconciliation. If the college approves online payments, integrate a provider such as Razorpay using its official server-side SDK and test mode first. Never collect card data, UPI PINs or OTPs in this app; redirect to the provider's hosted checkout. Do not store card details.

## 6. SMS/OTP — not connected by default

SMS providers generally require account verification and may incur charges. Email is the optional first notification channel. Add SMS only if the college has an approved provider and consent/opt-out procedures.

## Environment variables

See `.env.example`. For local use, export variables in the terminal or use a trusted dotenv loader. Do not commit a real `.env` file. On hosting platforms, configure secrets in the platform dashboard.

## Important distinction

The app's core student, attendance, result, complaint, notice and assignment data is stored in SQLite; those features do not require external APIs. External APIs are only used for optional AI, email and weather services.
