from flask import Flask, render_template, request, jsonify, redirect, url_for, session, flash, abort
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
import sqlite3, os, re
from datetime import datetime
from werkzeug.utils import secure_filename
from werkzeug.exceptions import RequestEntityTooLarge
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
import json, urllib.request, urllib.error
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "dev-only-change-me")
app.config["MAX_CONTENT_LENGTH"] = 10 * 1024 * 1024
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax", SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE", "0") == "1")
UPLOAD_DIR = os.path.join(os.path.dirname(__file__), "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)
ALLOWED_EXTENSIONS = {"pdf", "doc", "docx", "ppt", "pptx", "png", "jpg", "jpeg", "txt", "zip"}
DB_PATH = os.path.join(os.path.dirname(__file__), "helpdesk.db")

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS students (
        student_id TEXT PRIMARY KEY,
        full_name TEXT NOT NULL,
        email TEXT,
        phone TEXT,
        course TEXT,
        department TEXT,
        admission_date TEXT,
        year TEXT,
        fees_total REAL DEFAULT 0,
        fees_paid REAL DEFAULT 0,
        exam_status TEXT DEFAULT 'Not announced',
        timetable TEXT DEFAULT 'Contact your department for the latest timetable.'
    );
    CREATE TABLE IF NOT EXISTS faqs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        category TEXT NOT NULL,
        question TEXT NOT NULL,
        answer TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS admins (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS class_schedule (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        course TEXT NOT NULL, semester TEXT NOT NULL, day TEXT NOT NULL,
        start_time TEXT NOT NULL, end_time TEXT NOT NULL, subject TEXT NOT NULL,
        faculty TEXT, room TEXT
    );
    CREATE TABLE IF NOT EXISTS exam_schedule (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        course TEXT NOT NULL, semester TEXT NOT NULL, exam_date TEXT NOT NULL,
        start_time TEXT NOT NULL, end_time TEXT NOT NULL, subject TEXT NOT NULL,
        seat_note TEXT DEFAULT 'Check your hall ticket for the seat number.'
    );
    CREATE TABLE IF NOT EXISTS college_events (
        id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, category TEXT NOT NULL,
        event_date TEXT NOT NULL, start_time TEXT, venue TEXT, description TEXT,
        registration TEXT DEFAULT 'Contact the event coordinator to register.'
    );
    CREATE TABLE IF NOT EXISTS student_accounts (
        id INTEGER PRIMARY KEY AUTOINCREMENT, student_id TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(student_id) REFERENCES students(student_id)
    );
    CREATE TABLE IF NOT EXISTS attendance (
        id INTEGER PRIMARY KEY AUTOINCREMENT, student_id TEXT NOT NULL,
        attendance_date TEXT NOT NULL, subject TEXT DEFAULT '', status TEXT NOT NULL CHECK(status IN ('Present','Absent','Late')),
        FOREIGN KEY(student_id) REFERENCES students(student_id)
    );
    CREATE TABLE IF NOT EXISTS notices (
        id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, body TEXT NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP, expires_on TEXT
    );
    CREATE TABLE IF NOT EXISTS assignments (
        id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, description TEXT,
        course TEXT, due_date TEXT, filename TEXT, uploaded_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS results (
        id INTEGER PRIMARY KEY AUTOINCREMENT, student_id TEXT NOT NULL,
        semester TEXT NOT NULL, subject TEXT NOT NULL, marks REAL NOT NULL,
        max_marks REAL NOT NULL DEFAULT 100, published_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(student_id) REFERENCES students(student_id)
    );
    CREATE TABLE IF NOT EXISTS complaints (
        id INTEGER PRIMARY KEY AUTOINCREMENT, student_id TEXT NOT NULL,
        subject TEXT NOT NULL, message TEXT NOT NULL, status TEXT DEFAULT 'Submitted',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(student_id) REFERENCES students(student_id)
    );
    CREATE TABLE IF NOT EXISTS notifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT, student_id TEXT,
        title TEXT NOT NULL, body TEXT NOT NULL, is_read INTEGER DEFAULT 0,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(student_id) REFERENCES students(student_id)
    );
    CREATE TABLE IF NOT EXISTS chat_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT, session_key TEXT NOT NULL,
        role TEXT NOT NULL, message TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    """)
    if conn.execute("SELECT COUNT(*) FROM students").fetchone()[0] == 0:
        students = [
            ("STU1001","Aarav Sharma","aarav@example.com","9000000001","BSc Computer Science","Computer Science","2024-07-15","Second Year",45000,30000,"Hall ticket available","Mon: Python 10 AM; Tue: DBMS 11 AM; Wed: Networks 9 AM"),
            ("STU1002","Diya Patil","diya@example.com","9000000002","BCom","Commerce","2023-08-02","Third Year",38000,38000,"Results declared","Mon: Accounts 10 AM; Tue: Economics 11 AM; Thu: Taxation 9 AM"),
            ("STU1003","Kabir Khan","kabir@example.com","9000000003","BA English","Arts","2025-07-10","First Year",32000,12000,"Schedule pending","Mon: Literature 9 AM; Wed: Grammar 11 AM; Fri: History 10 AM")
        ]
        conn.executemany("""INSERT INTO students
        (student_id,full_name,email,phone,course,department,admission_date,year,fees_total,fees_paid,exam_status,timetable)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""", students)
    if conn.execute("SELECT COUNT(*) FROM faqs").fetchone()[0] == 0:
        faqs = [
            ("Admissions","How can I apply for admission?","Visit the college admission office or official admission portal. Keep your previous marksheets, ID proof and photographs ready."),
            ("Admissions","What documents are required for admission?","Common documents include previous marksheets, school leaving certificate, ID proof, photographs and category certificate if applicable. Confirm the current list with the admission office."),
            ("Fees","How can I pay my fees?","Fees can be paid through the college fee counter or the official online payment portal. Keep the receipt for your records."),
            ("Fees","Where can I ask about scholarships?","Contact the scholarship section with your student ID and required supporting documents."),
            ("Examinations","When will the exam timetable be released?","The examination section publishes the timetable on the official notice board or student portal. Check announcements regularly."),
            ("Timetable","Where can I find my class timetable?","Use the Student ID lookup after signing in, or contact your department for the latest timetable."),
            ("Activities","How can I join college activities?","Watch the student notice board and contact the cultural or sports committee to register for activities."),
            ("Contact","How can I contact the college office?","Visit the college office during working hours or use the contact details published on the official college website.")
        ]
        conn.executemany("INSERT INTO faqs(category,question,answer) VALUES (?,?,?)", faqs)
    # Clearly labelled fictional demo timetable: BSc Computer Science, Semester III.
    if conn.execute("SELECT COUNT(*) FROM class_schedule").fetchone()[0] == 0:
        class_rows = [
            ("BSc Computer Science", "Semester III", "Monday", "09:00 AM", "10:00 AM", "Python Programming", "Prof. Mehta", "Lab 1"),
            ("BSc Computer Science", "Semester III", "Monday", "10:15 AM", "11:15 AM", "Database Management", "Prof. Shah", "Room 204"),
            ("BSc Computer Science", "Semester III", "Monday", "11:30 AM", "12:30 PM", "Computer Networks", "Prof. Patil", "Room 204"),
            ("BSc Computer Science", "Semester III", "Monday", "01:15 PM", "02:15 PM", "Operating Systems", "Prof. Kulkarni", "Room 204"),
            ("BSc Computer Science", "Semester III", "Monday", "02:30 PM", "03:30 PM", "Python Practical", "Prof. Mehta", "Lab 1"),
            ("BSc Computer Science", "Semester III", "Tuesday", "09:00 AM", "10:00 AM", "Database Management", "Prof. Shah", "Room 204"),
            ("BSc Computer Science", "Semester III", "Tuesday", "10:15 AM", "11:15 AM", "Mathematics for Computing", "Prof. Joshi", "Room 105"),
            ("BSc Computer Science", "Semester III", "Tuesday", "11:30 AM", "12:30 PM", "Python Programming", "Prof. Mehta", "Room 204"),
            ("BSc Computer Science", "Semester III", "Tuesday", "01:15 PM", "02:15 PM", "Computer Networks", "Prof. Patil", "Room 204"),
            ("BSc Computer Science", "Semester III", "Tuesday", "02:30 PM", "03:30 PM", "DBMS Practical", "Prof. Shah", "Lab 2"),
            ("BSc Computer Science", "Semester III", "Wednesday", "09:00 AM", "10:00 AM", "Operating Systems", "Prof. Kulkarni", "Room 204"),
            ("BSc Computer Science", "Semester III", "Wednesday", "10:15 AM", "11:15 AM", "Python Programming", "Prof. Mehta", "Room 204"),
            ("BSc Computer Science", "Semester III", "Wednesday", "11:30 AM", "12:30 PM", "Mathematics for Computing", "Prof. Joshi", "Room 105"),
            ("BSc Computer Science", "Semester III", "Wednesday", "01:15 PM", "02:15 PM", "Computer Networks", "Prof. Patil", "Room 204"),
            ("BSc Computer Science", "Semester III", "Wednesday", "02:30 PM", "03:30 PM", "Network Lab", "Prof. Patil", "Lab 3"),
            ("BSc Computer Science", "Semester III", "Thursday", "09:00 AM", "10:00 AM", "Mathematics for Computing", "Prof. Joshi", "Room 105"),
            ("BSc Computer Science", "Semester III", "Thursday", "10:15 AM", "11:15 AM", "Database Management", "Prof. Shah", "Room 204"),
            ("BSc Computer Science", "Semester III", "Thursday", "11:30 AM", "12:30 PM", "Operating Systems", "Prof. Kulkarni", "Room 204"),
            ("BSc Computer Science", "Semester III", "Thursday", "01:15 PM", "02:15 PM", "Python Programming", "Prof. Mehta", "Room 204"),
            ("BSc Computer Science", "Semester III", "Thursday", "02:30 PM", "03:30 PM", "OS Practical", "Prof. Kulkarni", "Lab 2"),
            ("BSc Computer Science", "Semester III", "Friday", "09:00 AM", "10:00 AM", "Computer Networks", "Prof. Patil", "Room 204"),
            ("BSc Computer Science", "Semester III", "Friday", "10:15 AM", "11:15 AM", "Mathematics for Computing", "Prof. Joshi", "Room 105"),
            ("BSc Computer Science", "Semester III", "Friday", "11:30 AM", "12:30 PM", "Database Management", "Prof. Shah", "Room 204"),
            ("BSc Computer Science", "Semester III", "Friday", "01:15 PM", "02:15 PM", "Library / Tutorial", "Class Coordinator", "Library")
        ]
        conn.executemany("INSERT INTO class_schedule (course,semester,day,start_time,end_time,subject,faculty,room) VALUES (?,?,?,?,?,?,?,?)", class_rows)

    # Add more fictional demo class timetables without deleting any existing college data.
    # The BVoc CSF entry is B.Voc Cyber Security and Forensics, Second Year / Semester III.
    extra_courses = {
        "B.Voc Cyber Security and Forensics": {
            "Second Year (Semester III)": [
                ("Monday", "09:00 AM", "10:00 AM", "Digital Forensics", "Prof. Deshmukh", "Room 301"),
                ("Monday", "10:15 AM", "11:15 AM", "Network Security", "Prof. Rao", "Room 301"),
                ("Monday", "11:30 AM", "12:30 PM", "Python for Security", "Prof. Kulkarni", "Lab 4"),
                ("Monday", "01:15 PM", "02:15 PM", "Cyber Law", "Prof. Patil", "Room 301"),
                ("Tuesday", "09:00 AM", "10:00 AM", "Ethical Hacking", "Prof. Rao", "Lab 4"),
                ("Tuesday", "10:15 AM", "11:15 AM", "Digital Forensics", "Prof. Deshmukh", "Room 301"),
                ("Tuesday", "11:30 AM", "12:30 PM", "Linux Administration", "Prof. Shah", "Lab 3"),
                ("Tuesday", "01:15 PM", "02:15 PM", "Network Security Practical", "Prof. Rao", "Lab 4"),
                ("Wednesday", "09:00 AM", "10:00 AM", "Cyber Law", "Prof. Patil", "Room 301"),
                ("Wednesday", "10:15 AM", "11:15 AM", "Python for Security", "Prof. Kulkarni", "Lab 4"),
                ("Wednesday", "11:30 AM", "12:30 PM", "Incident Response", "Prof. Deshmukh", "Room 301"),
                ("Wednesday", "01:15 PM", "02:15 PM", "Digital Forensics Practical", "Prof. Deshmukh", "Lab 4"),
                ("Thursday", "09:00 AM", "10:00 AM", "Network Security", "Prof. Rao", "Room 301"),
                ("Thursday", "10:15 AM", "11:15 AM", "Ethical Hacking", "Prof. Rao", "Lab 4"),
                ("Thursday", "11:30 AM", "12:30 PM", "Linux Administration", "Prof. Shah", "Lab 3"),
                ("Thursday", "01:15 PM", "02:15 PM", "Cyber Law Tutorial", "Prof. Patil", "Room 301"),
                ("Friday", "09:00 AM", "10:00 AM", "Incident Response", "Prof. Deshmukh", "Room 301"),
                ("Friday", "10:15 AM", "11:15 AM", "Digital Forensics", "Prof. Deshmukh", "Room 301"),
                ("Friday", "11:30 AM", "12:30 PM", "Python for Security Practical", "Prof. Kulkarni", "Lab 4"),
                ("Friday", "01:15 PM", "02:15 PM", "Library / Project Work", "Class Coordinator", "Library")
            ]
        },
        "BCom": {
            "Second Year (Semester III)": [
                ("Monday", "09:00 AM", "10:00 AM", "Corporate Accounting", "Prof. Joshi", "Room 102"),
                ("Monday", "10:15 AM", "11:15 AM", "Business Economics", "Prof. More", "Room 102"),
                ("Monday", "11:30 AM", "12:30 PM", "Business Law", "Prof. Shah", "Room 102"),
                ("Tuesday", "09:00 AM", "10:00 AM", "Cost Accounting", "Prof. Joshi", "Room 102"),
                ("Tuesday", "10:15 AM", "11:15 AM", "Banking and Finance", "Prof. More", "Room 102"),
                ("Tuesday", "11:30 AM", "12:30 PM", "Business Communication", "Prof. Patil", "Room 102"),
                ("Wednesday", "09:00 AM", "10:00 AM", "Business Law", "Prof. Shah", "Room 102"),
                ("Wednesday", "10:15 AM", "11:15 AM", "Corporate Accounting", "Prof. Joshi", "Room 102"),
                ("Wednesday", "11:30 AM", "12:30 PM", "Computer Applications", "Prof. Kulkarni", "Lab 2"),
                ("Thursday", "09:00 AM", "10:00 AM", "Business Economics", "Prof. More", "Room 102"),
                ("Thursday", "10:15 AM", "11:15 AM", "Cost Accounting", "Prof. Joshi", "Room 102"),
                ("Thursday", "11:30 AM", "12:30 PM", "Computer Applications Practical", "Prof. Kulkarni", "Lab 2"),
                ("Friday", "09:00 AM", "10:00 AM", "Banking and Finance", "Prof. More", "Room 102"),
                ("Friday", "10:15 AM", "11:15 AM", "Business Communication", "Prof. Patil", "Room 102"),
                ("Friday", "11:30 AM", "12:30 PM", "Tutorial", "Class Coordinator", "Room 102")
            ]
        },
        "BA English": {
            "First Year (Semester I)": [
                ("Monday", "09:00 AM", "10:00 AM", "Introduction to Literature", "Prof. Fernandes", "Room 205"),
                ("Monday", "10:15 AM", "11:15 AM", "Communication Skills", "Prof. D'Souza", "Room 205"),
                ("Monday", "11:30 AM", "12:30 PM", "Indian Writing", "Prof. Khan", "Room 205"),
                ("Tuesday", "09:00 AM", "10:00 AM", "English Grammar", "Prof. D'Souza", "Room 205"),
                ("Tuesday", "10:15 AM", "11:15 AM", "Introduction to Literature", "Prof. Fernandes", "Room 205"),
                ("Tuesday", "11:30 AM", "12:30 PM", "Environmental Studies", "Prof. Patil", "Room 205"),
                ("Wednesday", "09:00 AM", "10:00 AM", "Indian Writing", "Prof. Khan", "Room 205"),
                ("Wednesday", "10:15 AM", "11:15 AM", "English Grammar", "Prof. D'Souza", "Room 205"),
                ("Wednesday", "11:30 AM", "12:30 PM", "Communication Skills", "Prof. D'Souza", "Room 205"),
                ("Thursday", "09:00 AM", "10:00 AM", "Environmental Studies", "Prof. Patil", "Room 205"),
                ("Thursday", "10:15 AM", "11:15 AM", "Indian Writing", "Prof. Khan", "Room 205"),
                ("Friday", "09:00 AM", "10:00 AM", "Introduction to Literature", "Prof. Fernandes", "Room 205"),
                ("Friday", "10:15 AM", "11:15 AM", "Library Reading", "Class Coordinator", "Library")
            ]
        },
        "BBA": {
            "First Year (Semester II)": [
                ("Monday", "09:00 AM", "10:00 AM", "Principles of Management", "Prof. Mehta", "Room 110"),
                ("Monday", "10:15 AM", "11:15 AM", "Business Mathematics", "Prof. Joshi", "Room 110"),
                ("Monday", "11:30 AM", "12:30 PM", "Marketing Basics", "Prof. Shah", "Room 110"),
                ("Tuesday", "09:00 AM", "10:00 AM", "Business Communication", "Prof. Patil", "Room 110"),
                ("Tuesday", "10:15 AM", "11:15 AM", "Principles of Management", "Prof. Mehta", "Room 110"),
                ("Tuesday", "11:30 AM", "12:30 PM", "Computer Applications", "Prof. Kulkarni", "Lab 2"),
                ("Wednesday", "09:00 AM", "10:00 AM", "Marketing Basics", "Prof. Shah", "Room 110"),
                ("Wednesday", "10:15 AM", "11:15 AM", "Business Mathematics", "Prof. Joshi", "Room 110"),
                ("Wednesday", "11:30 AM", "12:30 PM", "Computer Applications Practical", "Prof. Kulkarni", "Lab 2"),
                ("Thursday", "09:00 AM", "10:00 AM", "Business Communication", "Prof. Patil", "Room 110"),
                ("Thursday", "10:15 AM", "11:15 AM", "Marketing Basics", "Prof. Shah", "Room 110"),
                ("Friday", "09:00 AM", "10:00 AM", "Principles of Management", "Prof. Mehta", "Room 110"),
                ("Friday", "10:15 AM", "11:15 AM", "Tutorial", "Class Coordinator", "Room 110")
            ]
        }
    }
    for course_name, year_groups in extra_courses.items():
        for semester_name, periods in year_groups.items():
            for day, start, end, subject, faculty, room in periods:
                conn.execute("""INSERT INTO class_schedule (course,semester,day,start_time,end_time,subject,faculty,room)
                    SELECT ?,?,?,?,?,?,?,? WHERE NOT EXISTS (
                    SELECT 1 FROM class_schedule WHERE course=? AND semester=? AND day=? AND start_time=? AND subject=?)""",
                    (course_name, semester_name, day, start, end, subject, faculty, room,
                     course_name, semester_name, day, start, subject))

    # Fictional sample examination schedule. Replace with the institution's approved dates.
    if conn.execute("SELECT COUNT(*) FROM exam_schedule").fetchone()[0] == 0:
        exam_rows = [
            ("BSc Computer Science", "Semester III", "2026-12-02", "10:00 AM", "01:00 PM", "Python Programming", "Bring college ID and hall ticket."),
            ("BSc Computer Science", "Semester III", "2026-12-04", "10:00 AM", "01:00 PM", "Database Management", "Bring college ID and hall ticket."),
            ("BSc Computer Science", "Semester III", "2026-12-07", "10:00 AM", "01:00 PM", "Computer Networks", "Bring college ID and hall ticket."),
            ("BSc Computer Science", "Semester III", "2026-12-09", "10:00 AM", "01:00 PM", "Operating Systems", "Bring college ID and hall ticket."),
            ("BSc Computer Science", "Semester III", "2026-12-11", "10:00 AM", "01:00 PM", "Mathematics for Computing", "Bring college ID and hall ticket.")
        ]
        conn.executemany("INSERT INTO exam_schedule (course,semester,exam_date,start_time,end_time,subject,seat_note) VALUES (?,?,?,?,?,?,?)", exam_rows)

    # Extra fictional exam timetables for the additional demo courses.
    extra_exams = {
        "B.Voc Cyber Security and Forensics": ("Second Year (Semester III)", [
            ("2026-12-03", "10:00 AM", "01:00 PM", "Digital Forensics"),
            ("2026-12-05", "10:00 AM", "01:00 PM", "Network Security"),
            ("2026-12-08", "10:00 AM", "01:00 PM", "Python for Security"),
            ("2026-12-10", "10:00 AM", "01:00 PM", "Cyber Law"),
            ("2026-12-12", "10:00 AM", "01:00 PM", "Ethical Hacking")]),
        "BCom": ("Second Year (Semester III)", [
            ("2026-12-03", "10:00 AM", "01:00 PM", "Corporate Accounting"),
            ("2026-12-06", "10:00 AM", "01:00 PM", "Business Economics"),
            ("2026-12-09", "10:00 AM", "01:00 PM", "Business Law"),
            ("2026-12-12", "10:00 AM", "01:00 PM", "Cost Accounting")]),
        "BA English": ("First Year (Semester I)", [
            ("2026-12-02", "10:00 AM", "01:00 PM", "Introduction to Literature"),
            ("2026-12-05", "10:00 AM", "01:00 PM", "English Grammar"),
            ("2026-12-08", "10:00 AM", "01:00 PM", "Indian Writing"),
            ("2026-12-11", "10:00 AM", "01:00 PM", "Communication Skills")]),
        "BBA": ("First Year (Semester II)", [
            ("2026-12-04", "10:00 AM", "01:00 PM", "Principles of Management"),
            ("2026-12-07", "10:00 AM", "01:00 PM", "Business Mathematics"),
            ("2026-12-10", "10:00 AM", "01:00 PM", "Marketing Basics"),
            ("2026-12-13", "10:00 AM", "01:00 PM", "Business Communication")])
    }
    for course_name, (semester_name, exams) in extra_exams.items():
        for exam_date, start, end, subject in exams:
            conn.execute("""INSERT INTO exam_schedule (course,semester,exam_date,start_time,end_time,subject,seat_note)
                SELECT ?,?,?,?,?,?,? WHERE NOT EXISTS (
                SELECT 1 FROM exam_schedule WHERE course=? AND semester=? AND exam_date=? AND subject=?)""",
                (course_name, semester_name, exam_date, start, end, subject,
                 "Bring college ID and hall ticket.", course_name, semester_name, exam_date, subject))

    # Fictional future events for demonstrating event/competition keyword search.
    if conn.execute("SELECT COUNT(*) FROM college_events").fetchone()[0] == 0:
        event_rows = [
            ("GreenSphere Annual College Fest", "Fest", "2026-12-05", "10:00 AM", "Main College Ground", "Annual cultural fest with music, dance, food stalls and student performances.", "Register with the Cultural Committee by 2026-12-01."),
            ("CodeSprint Hackathon", "Technology Competition", "2026-12-12", "09:00 AM", "Computer Science Lab", "A  six-hour team coding challenge. Bring your laptop and college ID.", "Register your team of 2-4 students with the CS Department by 2026-12-08."),
            ("Battle of Bands", "Music Competition", "2026-12-16", "11:00 AM", "Auditorium", "Inter-department music and band performance competition.", "Auditions and registration at the Cultural Committee desk."),
            ("Campus Sports Meet", "Sports Competition", "2027-01-08", "08:00 AM", "Sports Ground", "Athletics, football, badminton and relay competitions.", "Register with the Sports Department by 2027-01-03."),
            ("Creative Canvas", "Art Competition", "2027-01-15", "10:30 AM", "Seminar Hall", "Poster making, photography and rangoli competitions.", "Submit your entry form to the Student Activity Cell by 2027-01-11.")
        ]
        conn.executemany("INSERT INTO college_events (title,category,event_date,start_time,venue,description,registration) VALUES (?,?,?,?,?,?,?)", event_rows)

    if conn.execute("SELECT COUNT(*) FROM admins").fetchone()[0] == 0:
        conn.execute("INSERT INTO admins(username,password_hash) VALUES (?,?)",
                     (os.environ.get("ADMIN_USERNAME", "admin"), generate_password_hash(os.environ.get("ADMIN_PASSWORD", "admin123"))))
    conn.commit()
    conn.close()

def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("admin"):
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper

@app.route("/")
def index():
    return render_template("index.html", logged_in=bool(session.get("admin")))

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username","").strip()
        password = request.form.get("password","")
        conn = get_db()
        admin = conn.execute("SELECT * FROM admins WHERE username=?", (username,)).fetchone()
        conn.close()
        if admin and check_password_hash(admin["password_hash"], password):
            session["admin"] = username
            return redirect(url_for("dashboard"))
        flash("Incorrect username or password.", "error")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))

@app.route("/dashboard")
@admin_required
def dashboard():
    conn = get_db()
    students = conn.execute("SELECT * FROM students ORDER BY student_id").fetchall()
    count = conn.execute("SELECT COUNT(*) FROM students").fetchone()[0]
    complaints = conn.execute("SELECT * FROM complaints ORDER BY id DESC LIMIT 30").fetchall()
    conn.close()
    return render_template("dashboard.html", students=students, count=count, complaints=complaints)

@app.route("/student/<student_id>")
@admin_required
def student_detail(student_id):
    conn = get_db()
    student = conn.execute("SELECT * FROM students WHERE student_id=?", (student_id.upper(),)).fetchone()
    conn.close()
    if not student:
        flash("Student ID not found.", "error")
        return redirect(url_for("dashboard"))
    return render_template("student.html", student=student)

@app.route("/student/add", methods=["POST"])
@admin_required
def add_student():
    data = request.form
    try:
        conn = get_db()
        conn.execute("""INSERT INTO students
        (student_id,full_name,email,phone,course,department,admission_date,year,fees_total,fees_paid,exam_status,timetable)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
        (data["student_id"].strip().upper(),data["full_name"].strip(),data.get("email",""),
         data.get("phone",""),data.get("course",""),data.get("department",""),
         data.get("admission_date",""),data.get("year",""),float(data.get("fees_total") or 0),
         float(data.get("fees_paid") or 0),data.get("exam_status","Not announced"),
         data.get("timetable","")))
        conn.commit()
        conn.close()
        flash("Student added successfully.", "success")
    except sqlite3.IntegrityError:
        flash("That Student ID already exists.", "error")
    except (ValueError, KeyError):
        flash("Please check the student details and fee amounts.", "error")
    return redirect(url_for("dashboard"))

# Question understanding: recognise common ways students phrase the same request.
HELP_ANSWERS = {
    "admission_apply": "ADMISSION APPLICATION\n\n1. Check the college's official admission notice for the courses offered, eligibility, application dates and application link.\n2. Open the official admission portal or collect the form from the admission office.\n3. Select your course and fill in your personal and academic details carefully.\n4. Upload or submit the required documents.\n5. Pay the application fee only through a payment method confirmed by the college.\n6. Save the application number and payment receipt.\n7. Follow the portal or admission office for merit-list, document-verification and confirmation updates.\n\nThe college name and official application link have not been configured in this demo. Please confirm the current process with your college admission office.",
    "admission_documents": "DOCUMENTS GENERALLY REQUIRED\n\nKeep these documents ready (the exact list can vary by course, year and admission category):\n• Previous qualifying examination marksheet / certificate\n• School or college leaving / transfer certificate, if required\n• Government photo ID\n• Recent passport-size photographs\n• Date-of-birth proof, if requested\n• Caste / category / EWS certificate, if applicable\n• Domicile certificate, if applicable\n• Migration certificate, if applicable\n• Entrance-exam scorecard, if the course requires one\n\nCarry originals for verification and submit photocopies or uploads as instructed. Confirm the final checklist in the current college admission notice.",
    "admission_process": "ADMISSION PROCESS\n\nThe usual process is: (1) read the official admission notice and check eligibility, (2) register on the admission portal or collect the form, (3) complete the application, (4) upload documents, (5) pay the application fee using an approved method, (6) check the merit list / entrance result if applicable, (7) attend document verification, and (8) pay the admission fees to confirm your seat.\n\nCourse-specific rules and dates may differ. Use the current college notice as the final authority.",
    "admission_start": "ADMISSION START DATE\n\nThe admission start date changes each academic year and may differ by course. This demo does not contain your college's current admission calendar, so I should not guess a date. Please check the latest admission notification on the college website / notice board or contact the admission office. If you share the official date, it can be added to the chatbot's college information.",
    "admission_form": "WHERE TO GET THE ADMISSION FORM\n\nThe form is usually available through the college's official online admission portal. Some colleges also provide an offline form at the admission office. Use only the link published by the college; avoid unofficial third-party forms. The official college link has not yet been added to this demo, so please contact the admission office or check the college website.",
    "fees_pay": "HOW TO PAY COLLEGE FEES\n\n1. Sign in to the official student / fee portal, if your college provides one, or visit the accounts section.\n2. Check your student ID, fee head and outstanding amount before paying.\n3. Choose only a payment method officially accepted by the college (for example, online payment or the accounts counter, if offered).\n4. Complete the payment and wait for confirmation.\n5. Download or collect the receipt and keep the transaction/reference number.\n\nDo not pay into a personal bank account or share your OTP, PIN or password. The exact payment options and portal link must be confirmed by your college accounts office.",
    "scholarship": "SCHOLARSHIP HELP\n\nFor scholarship information, contact the college scholarship / student welfare section. Ask which schemes are currently open, their eligibility rules, income or category requirements, deadlines and required documents. Commonly requested documents may include a student ID, admission proof, marksheets, income certificate, bank details and applicable category certificate.\n\nAlso check the relevant official government scholarship portal if your college directs you there. Scholarship availability and deadlines vary; this demo does not have live scheme information.",
    "fees_pending": "HOW TO CHECK PENDING FEES\n\nOpen the official student fee portal and look for Fee Details, Account Statement or Outstanding Balance. Compare the total fee with payments already credited, and check whether any instalment, late fee or concession is listed. If a payment is missing, show the receipt / transaction reference to the accounts office.\n\nFor an individual student's stored fee balance, an authorised staff member can sign in and search using the Student ID. Personal fee records are not shown to public visitors.",
    "payment_methods": "PAYMENT METHODS\n\nColleges may support online payment through their official portal, card / UPI / net banking, bank challan or payment at the accounts counter. The available methods differ by institution. Please use only the methods listed on your college's official fee instructions and retain the receipt. This demo does not know which methods your college has enabled; confirm with the accounts office.",
    "fee_receipt": "HOW TO GET A FEE RECEIPT\n\nAfter a successful online payment, open the fee portal's Payment History / Receipts section and download or print the receipt. For an offline payment, request the stamped receipt from the accounts counter. Check that the receipt shows your name, Student ID, amount, date and transaction / receipt number. If the payment was deducted but no receipt appears, do not pay again immediately—contact the accounts office with your transaction reference.",
    "exam_timetable": "EXAMINATION TIMETABLE\n\nThe examination timetable is normally issued by the college examination section or university. Check the official examination portal, college website and notice board. Before the exam, verify the subject, date, time, paper code, reporting time and exam centre. Timetables can be revised, so check for updated notices.\n\nThis demo does not contain your current exam calendar and cannot provide an unannounced date.",
    "results": "RESULT DECLARATION\n\nResults are published by the college or affiliated university after evaluation. Check the official result portal and examination notices. Keep your seat number / roll number and any required login details ready. If the result is not available yet, contact the examination section for the official expected announcement. This demo does not have live result dates and should not guess them.",
    "hall_ticket": "HOW TO DOWNLOAD A HALL TICKET\n\n1. Open the official college / university examination portal.\n2. Choose the Hall Ticket / Admit Card section.\n3. Enter the requested details, such as your registration number, seat number or Student ID.\n4. Verify your name, photograph, subjects, exam dates and centre.\n5. Download and print the hall ticket if the exam instructions require a printed copy.\n\nIf the hall ticket is missing or contains an error, contact the examination section before the exam. Never share your portal password or OTP with anyone.",
    "exam_notices": "WHERE TO CHECK EXAMINATION NOTICES\n\nCheck these official channels: (1) college website's Examination / Notices section, (2) university examination portal, (3) college notice board, and (4) official student portal or college communication channel. Pay attention to revised timetables, form deadlines, hall-ticket notices and result announcements. Follow the latest dated notice if two notices conflict.",
    "result_error": "IF THERE IS AN ERROR IN YOUR RESULT\n\n1. Take a screenshot or download the result PDF.\n2. Note your name, seat / roll number, subject and the exact error.\n3. Contact the college examination section as soon as possible.\n4. Ask whether a rechecking, verification, photocopy of answer book or revaluation application is available.\n5. Submit the prescribed form and fee before the official deadline, if applicable.\n6. Keep the acknowledgement / receipt for follow-up.\n\nDo not assume the result will change automatically. The examination office can explain the applicable university procedure.",
    "class_timetable": "WHERE TO FIND YOUR CLASS TIMETABLE\n\nCheck your department notice board, official student portal, college website or timetable shared by your class coordinator. Confirm your course, year / semester, division, classroom and effective date. If two versions differ, ask your department office which one is current. An authorised staff member can also look up a student's timetable from the student record in this demo.",
    "lecture_schedule": "LECTURE / CLASS SCHEDULE\n\nYour lecture schedule depends on your course, year, semester and division. Check the latest department timetable for subject, faculty, time and classroom. If you tell me your course and year, I can guide you to the right timetable source; the college's full timetable has not been configured in this demo.",
    "practicals": "PRACTICAL SESSION INFORMATION\n\nPractical batches and timings are usually shared by the department or laboratory in-charge. Check your department timetable for batch number, lab room, reporting time and required equipment / journal. Practical schedules can differ from lecture schedules. Contact your subject teacher or department office if your batch is not listed.",
    "exam_schedule_location": "WHERE TO FIND THE EXAMINATION TIMETABLE\n\nUse the official university examination portal or your college website's Examination / Notices section. You can also check the examination notice board or ask the examination section. Download the latest version and check whether a revised timetable has been published.",
    "activities": "COLLEGE ACTIVITIES\n\nColleges commonly organise cultural programmes, annual festivals, sports competitions, seminars, workshops, guest lectures, technical events, NSS / NCC activities, clubs and community outreach programmes. The actual activities depend on your college calendar. Check the student notice board, official website and student council announcements for confirmed events.",
    "join_events": "HOW TO PARTICIPATE IN COLLEGE EVENTS\n\n1. Check the event announcement for eligibility, date, venue and registration deadline.\n2. Register using the official form or with the organising committee.\n3. If required, contact the faculty coordinator or student council.\n4. Keep your student ID and registration confirmation.\n5. Follow the event rules and attend the briefing / practice session.\n\nFor a specific event, contact the cultural committee or student activity coordinator.",
    "sports": "HOW TO JOIN THE COLLEGE SPORTS TEAM\n\nContact the sports department / physical education instructor and ask about trials, team selection, practice timings and eligibility. Watch for sports notices and register before the deadline. You may be asked to provide your student ID, medical fitness information or previous sports certificates. Selection rules are set by your college.",
    "cultural_events": "UPCOMING CULTURAL EVENTS\n\nUpcoming event dates must come from the current college activity calendar. Check the cultural committee, student council, official college website and notice board for confirmed dates and registration links. This demo does not have live event-calendar data, so it will not invent upcoming events."
}

INTENT_PATTERNS = [
    ("admission_documents", [r"document", r"certificate", r"paperwork", r"what.*(bring|submit|upload)", r"required.*(for|admission)"]),
    ("admission_start", [r"when.*(admission|apply).*(start|begin|open)", r"(admission|application).*(start|begin|date|open)", r"admission kab"]),
    ("admission_form", [r"(where|how).*(admission|application).*(form|portal|link)", r"admission form"]),
    ("admission_process", [r"admission process", r"steps.*admission", r"procedure.*admission", r"how.*admission.*work"]),
    ("admission_apply", [r"apply", r"admission", r"enrol", r"enroll", r"register.*course"]),
    ("scholarship", [r"scholarship", r"financial aid", r"fee concession", r"education loan"]),
    ("fees_pending", [r"pending", r"balance", r"outstanding", r"dues", r"how much.*(owe|left|pay)", r"remaining.*fee"]),
    ("fee_receipt", [r"receipt", r"payment proof", r"fee slip", r"transaction.*receipt"]),
    ("payment_methods", [r"payment method", r"pay.*(upi|online|cash|card|bank|mode)", r"which.*(mode|method).*(fee|pay)"]),
    ("fees_pay", [r"pay.*fee", r"fee.*pay", r"fees.*payment", r"how.*(submit|deposit).*fee"]),
    ("hall_ticket", [r"hall ticket", r"admit card", r"download.*(ticket|card)"]),
    ("exam_schedule_location", [r"where.*(find|check|see).*(exam|examination).*(time.?table|schedule)"]),
    ("exam_timetable", [r"exam.*(time.?table|schedule|date)", r"(time.?table|schedule).*(exam|examination)", r"when.*exam"]),
    ("result_error", [r"error.*result", r"wrong.*(mark|result|name)", r"result.*(incorrect|mistake|wrong)", r"revaluation", r"rechecking"]),
    ("results", [r"result", r"marksheet", r"marks", r"grade", r"when.*declare"]),
    ("exam_notices", [r"exam.*notice", r"examination.*notice", r"where.*exam.*(update|notice)"]),
    ("practicals", [r"practical", r"laboratory", r"lab session", r"lab timing"]),
    ("class_timetable", [r"class.*(time.?table|schedule)", r"where.*(find|check|see).*(time.?table)", r"my.*time.?table"]),
    ("lecture_schedule", [r"lecture", r"class timing", r"period timing", r"schedule.*class"]),
    ("cultural_events", [r"upcoming", r"cultural event", r"college fest", r"festival", r"event.*date"]),
    ("sports", [r"sports team", r"join.*sports", r"sports.*join", r"team selection", r"sports trial"]),
    ("join_events", [r"participate", r"join.*event", r"register.*event", r"take part", r"event.*join"]),
    ("activities", [r"activities", r"activity", r"college event", r"club", r"nss", r"ncc", r"workshop", r"seminar"]),
]

def detect_intent(message):
    normalized = re.sub(r"[^a-z0-9₹ ]+", " ", message.lower())
    normalized = re.sub(r"\s+", " ", normalized).strip()
    for intent, patterns in INTENT_PATTERNS:
        if any(re.search(pattern, normalized) for pattern in patterns):
            return intent
    return None

COURSE_ALIASES = [
    ("B.Voc Cyber Security and Forensics", ["b.voc cyber security and forensics", "bvoc cyber security and forensics", "b voc csf", "bvoc csf", "b.voc csf", "csf", "cyber security and forensics", "cyber forensics"]),
    ("BSc Computer Science", ["bsc computer science", "b.sc computer science", "bsc cs", "computer science", "bsc"]),
    ("BCom", ["b.com", "bcom", "commerce"]),
    ("BA English", ["ba english", "b.a. english", "english honours", "arts english"]),
    ("BBA", ["bba", "business administration"]),
]


def identify_course(message):
    text = message.lower().replace(".", " ")
    for course, aliases in COURSE_ALIASES:
        if any(alias.replace(".", " ") in text for alias in aliases):
            return course
    return None


def identify_year_or_semester(message):
    text = message.lower()
    # Semester can be written as sem 3, semester iii, third semester, etc.
    roman = {"i": 1, "ii": 2, "iii": 3, "iv": 4, "v": 5, "vi": 6}
    m = re.search(r"(?:sem(?:ester)?\s*)([1-6]|i{1,3}|iv|v|vi)\b", text)
    if m:
        raw = m.group(1)
        number = int(raw) if raw.isdigit() else roman[raw]
        return f"Semester {['I','II','III','IV','V','VI'][number-1]}"
    words = {"first": 1, "1st": 1, "fy": 1, "second": 2, "2nd": 2, "sy": 2, "third": 3, "3rd": 3, "ty": 3}
    m = re.search(r"\b(first|second|third|1st|2nd|3rd|fy|sy|ty)\s+year\b|\b(fy|sy|ty)\b", text)
    if m:
        word = m.group(1) or m.group(2)
        year = words[word]
        return f"{['First','Second','Third'][year-1]} Year"
    m = re.search(r"\b(year\s*[1-3])\b", text)
    if m:
        year = int(m.group(1)[-1])
        return f"{['First','Second','Third'][year-1]} Year"
    m = re.search(r"\b([1-3])\s*(?:st|nd|rd)?\s*year\b", text)
    if m:
        year = int(m.group(1))
        return f"{['First','Second','Third'][year-1]} Year"
    return None


def find_schedule_rows(conn, table, course, level):
    order_by = ("CASE day WHEN 'Monday' THEN 1 WHEN 'Tuesday' THEN 2 WHEN 'Wednesday' THEN 3 WHEN 'Thursday' THEN 4 WHEN 'Friday' THEN 5 WHEN 'Saturday' THEN 6 ELSE 7 END, start_time" if table == "class_schedule" else "exam_date")
    if level.endswith("Year"):
        year_semesters = {
            "First Year": ("%First Year%", "%Semester I%", "%Semester II%"),
            "Second Year": ("%Second Year%", "%Semester III%", "%Semester IV%"),
            "Third Year": ("%Third Year%", "%Semester V%", "%Semester VI%")
        }
        patterns = year_semesters[level]
        sql = f"SELECT * FROM {table} WHERE course=? AND (semester LIKE ? OR semester LIKE ? OR semester LIKE ?) ORDER BY {order_by}"
        return conn.execute(sql, (course, *patterns)).fetchall()
    sql = f"SELECT * FROM {table} WHERE course=? AND semester LIKE ? ORDER BY {order_by}"
    return conn.execute(sql, (course, f"%{level}%")).fetchall()


def format_class_timetable(conn, course, level, message):
    rows = find_schedule_rows(conn, "class_schedule", course, level)
    if not rows:
        return f"I don't have a demo class timetable saved for {course}, {level} yet. Please check with your department or ask the admin to add it."
    day_match = next((d for d in ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"] if d.lower() in message.lower()), None)
    selected = [r for r in rows if not day_match or r["day"] == day_match]
    title = f"{day_match.upper()} CLASS TIMETABLE" if day_match else "WEEKLY CLASS TIMETABLE"
    lines = [title, f"{course} — {level}", "(Sample timetable for project demonstration.)", ""]
    current_day = None
    for r in selected:
        if not day_match and current_day != r["day"]:
            current_day = r["day"]
            lines.append(f"\n{current_day.upper()}")
        lines.append(f"{r['start_time']}–{r['end_time']} | {r['subject']} | {r['room'] or 'Room TBA'} | {r['faculty'] or 'Faculty TBA'}")
    if not selected:
        return f"There are no classes listed for {day_match} in {course}, {level}."
    lines.append("\nIf your college has issued a revised timetable, follow the latest department notice.")
    return "\n".join(lines)


def format_exam_timetable(conn, course, level, message=None):
    rows = find_schedule_rows(conn, "exam_schedule", course, level)
    if message:
        query = message.lower()
        subject_rows = [r for r in rows if any(term in query for term in r["subject"].lower().split())]
        if subject_rows:
            rows = subject_rows
    if not rows:
        return f"I don't have a demo examination timetable saved for {course}, {level} yet. Please check the official exam notice."
    lines = [f"EXAMINATION TIMETABLE — {course}, {level}", "(Fictional demo dates. Confirm actual dates with your college.)", ""]
    for r in rows:
        date_label = datetime.strptime(r["exam_date"], "%Y-%m-%d").strftime("%d %b %Y")
        lines.append(f"{date_label} | {r['subject']} | {r['start_time']}–{r['end_time']}")
    lines.append("\nPlease verify the final date, reporting time and exam centre from your official hall ticket.")
    return "\n".join(lines)


def handle_schedule_request(conn, message, schedule_type):
    course = identify_course(message) or session.get("schedule_course")
    level = identify_year_or_semester(message) or session.get("schedule_level")
    session["pending_schedule_type"] = schedule_type
    if course:
        session["schedule_course"] = course
    if level:
        session["schedule_level"] = level
    if not course and not level:
        return ("Sure! Which course/class and which year or semester do you need?\n\n" 
                "For example: ‘B.Voc CSF, Second Year / Semester III’ or ‘BCom, Second Year’."), True
    if not course:
        return (f"Got it — {level}. Which course/class are you in?\n\n" 
                "Examples: B.Voc CSF, BSc Computer Science, BCom, BA English or BBA."), True
    if not level:
        return (f"Which year or semester for {course}?\n\nFor example: First Year, Second Year, Semester III or Semester IV."), True
    if schedule_type == "class_timetable":
        reply = format_class_timetable(conn, course, level, message)
    else:
        reply = format_exam_timetable(conn, course, level, message)
    session.pop("pending_schedule_type", None)
    session.pop("schedule_course", None)
    session.pop("schedule_level", None)
    return reply, False


def format_upcoming_events(conn, message):
    rows = conn.execute("SELECT * FROM college_events WHERE date(event_date) >= date('now') ORDER BY event_date").fetchall()
    if not rows:
        return "There are no upcoming demo events in the event calendar right now. Please check the college notice board for new announcements."
    text = message.lower()
    # Map everyday keywords to event categories / event themes.
    keyword_groups = {
        "fest": ["fest", "festival", "cultural", "dance", "singing", "music", "band"],
        "technology": ["coding", "code", "hackathon", "tech", "programming", "robot"],
        "sports": ["sport", "football", "cricket", "badminton", "athletics", "game"],
        "art": ["art", "drawing", "painting", "rangoli", "photography", "poster", "creative"],
    }
    selected = []
    specific_groups = [group for group, words in keyword_groups.items() if any(word in text for word in words)]
    wants_competitions = any(word in text for word in ["competition", "competitions", "contest", "contests", "compete"])
    wants_all = any(word in text for word in ["all events", "all activities", "what is upcoming", "what's upcoming", "whats upcoming", "upcoming events", "upcoming activities", "any events", "any activities"])

    for row in rows:
        haystack = (row["title"] + " " + row["category"] + " " + row["description"]).lower()
        category = row["category"].lower()
        if wants_all:
            selected.append(row)
        elif specific_groups:
            if any(word in haystack for group in specific_groups for word in keyword_groups[group]):
                selected.append(row)
        elif wants_competitions:
            if "competition" in category or "competition" in haystack:
                selected.append(row)
        elif any(word in text for word in ["fest", "festival"]):
            if "fest" in haystack or "cultural" in haystack:
                selected.append(row)
        elif any(word in text for word in ["event", "activity", "activities", "upcoming"]):
            selected.append(row)

    if not selected:
        # If a user asks generally about events without a recognisable filter, show the full demo calendar.
        selected = rows
    lines = ["UPCOMING COLLEGE EVENTS & COMPETITIONS", "(Sample demo calendar — dates and registrations are fictional.)", ""]
    for r in selected:
        date_label = datetime.strptime(r["event_date"], "%Y-%m-%d").strftime("%d %b %Y")
        lines.append(f"{r['title']} — {r['category']}\nDate: {date_label} at {r['start_time']}\nVenue: {r['venue']}\nAbout: {r['description']}\nRegistration: {r['registration']}\n")
    lines.append("For official dates, confirm with the college Student Activity Cell / notice board.")
    return "\n".join(lines)

@app.route("/api/chat", methods=["POST"])
def chat():
    payload = request.get_json(silent=True) or {}
    message = str(payload.get("message", "")).strip()
    if not message:
        return jsonify({"reply": "Please type a question so I can help."})
    if len(message) > 2000:
        return jsonify({"reply": "Please keep your question under 2,000 characters."}), 400
    session_key = session.get("student_id") or ("staff:" + session.get("admin", "visitor:" + (request.remote_addr or "unknown")))
    history_conn = get_db()
    history_conn.execute("INSERT INTO chat_history(session_key,role,message) VALUES (?,?,?)", (session_key,"user",message))
    history_conn.commit(); history_conn.close()

    # Student-specific records are confidential and only available to signed-in staff.
    student_match = re.search(r"\b(STU\d{4,})\b", message, re.I)
    if student_match:
        if not session.get("admin"):
            return jsonify({"reply": "Student records are confidential. Please sign in through Staff Login. Only authorised college staff can look up an individual Student ID."})
        conn = get_db()
        student = conn.execute("SELECT * FROM students WHERE student_id=?", (student_match.group(1).upper(),)).fetchone()
        conn.close()
        if not student:
            return jsonify({"reply": f"I could not find {student_match.group(1).upper()}. Please check the Student ID or add the student from the staff dashboard."})
        due = max(0, float(student["fees_total"]) - float(student["fees_paid"]))
        reply = (
            f"STUDENT PROFILE — {student['full_name']}\n"
            f"Student ID: {student['student_id']}\nCourse: {student['course']}\nDepartment: {student['department']}\n"
            f"Academic year: {student['year']}\nAdmission date: {student['admission_date']}\n"
            f"Email: {student['email']}\nPhone: {student['phone']}\n\n"
            f"FEE SUMMARY\nTotal: ₹{float(student['fees_total']):,.2f}\nPaid: ₹{float(student['fees_paid']):,.2f}\nBalance: ₹{due:,.2f}\n\n"
            f"Exam status: {student['exam_status']}\n\nClass timetable: {student['timetable']}"
        )
        session["last_intent"] = "student_lookup"
        return jsonify({"reply": reply})

    lower_message = message.lower()
    conn = get_db()
    pending_type = session.get("pending_schedule_type")
    is_exam_request = any(k in lower_message for k in ["exam timetable", "exam time table", "exam schedule", "examination timetable", "exam dates", "when are exams", "exam date", "exam routine"])
    is_class_request = any(k in lower_message for k in ["timetable", "time table", "class schedule", "lecture schedule", "today classes", "classes today", "my classes", "class timing"])
    if pending_type and not is_exam_request and not is_class_request:
        reply, waiting = handle_schedule_request(conn, message, pending_type)
        conn.close()
        return jsonify({"reply": reply, "intent": pending_type, "waiting_for_details": waiting})
    if is_exam_request:
        reply, waiting = handle_schedule_request(conn, message, "exam_timetable")
        conn.close()
        session["last_intent"] = "exam_timetable"
        return jsonify({"reply": reply, "intent": "exam_timetable", "waiting_for_details": waiting})
    if is_class_request:
        reply, waiting = handle_schedule_request(conn, message, "class_timetable")
        conn.close()
        session["last_intent"] = "class_timetable"
        return jsonify({"reply": reply, "intent": "class_timetable", "waiting_for_details": waiting})
    event_words = ["upcoming", "fest", "festival", "competition", "contest", "hackathon", "coding", "sports", "cultural", "dance", "singing", "music", "event", "activities", "activity", "photography", "rangoli", "art competition"]
    if any(k in lower_message for k in event_words):
        reply = format_upcoming_events(conn, message)
        conn.close()
        session["last_intent"] = "events"
        return jsonify({"reply": reply, "intent": "events"})
    conn.close()

    intent = detect_intent(message)
    if intent:
        session["last_intent"] = intent
        return jsonify({"reply": HELP_ANSWERS[intent], "intent": intent})

    # Handle short follow-up questions using the previous topic where possible.
    previous = session.get("last_intent")
    follow_up = re.sub(r"[^a-z0-9 ]+", " ", message.lower()).strip()
    if previous and follow_up in {"more", "tell me more", "explain", "explain more", "details", "more details", "what else", "and then", "next step"}:
        return jsonify({"reply": HELP_ANSWERS.get(previous, "Please ask a more specific question.")})

    # Supply only public, non-personal college knowledge to Gemini; never include student records.
    context_conn=get_db()
    faq_rows=context_conn.execute("SELECT category,question,answer FROM faqs ORDER BY category LIMIT 25").fetchall()
    notice_rows=context_conn.execute("SELECT title,body,created_at FROM notices WHERE expires_on IS NULL OR expires_on>=date('now') ORDER BY id DESC LIMIT 5").fetchall()
    context_conn.close()
    verified_context="\n\n".join([f"FAQ [{r['category']}] {r['question']}: {r['answer']}" for r in faq_rows] +
        [f"Current notice [{r['created_at']}] {r['title']}: {r['body']}" for r in notice_rows])
    ai_reply = ask_gemini(message, verified_context)
    if ai_reply:
        conn=get_db(); conn.execute("INSERT INTO chat_history(session_key,role,message) VALUES (?,?,?)", (session_key,"assistant",ai_reply)); conn.commit(); conn.close()
        return jsonify({"reply": ai_reply, "intent": "gemini"})
    fallback_reply = "I can help with admissions, required documents, admission dates and forms; fee payments, scholarships and receipts; examinations, hall tickets and results; class timetables and practicals; and college events and sports.\n\nTry asking a complete question, for example: ‘What documents are required for admission?’ or ‘How can I download my hall ticket?’ If you need an individual student record, sign in as authorised staff and include the Student ID."
    conn=get_db(); conn.execute("INSERT INTO chat_history(session_key,role,message) VALUES (?,?,?)", (session_key,"assistant",fallback_reply)); conn.commit(); conn.close()
    return jsonify({"reply": fallback_reply, "ai_enabled": bool(os.environ.get("GEMINI_API_KEY"))})


def student_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("student_id"):
            flash("Please sign in with your student account.", "error")
            return redirect(url_for("student_login"))
        return fn(*args, **kwargs)
    return wrapper

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

def send_email(to_email, subject, html):
    """Optional Resend integration. Returns False when not configured."""
    key = os.environ.get("RESEND_API_KEY")
    sender = os.environ.get("RESEND_FROM_EMAIL")
    if not key or not sender or not to_email:
        return False
    data = json.dumps({"from": sender, "to": [to_email], "subject": subject, "html": html}).encode()
    req = urllib.request.Request("https://api.resend.com/emails", data=data,
        headers={"Authorization": "Bearer " + key, "Content-Type": "application/json"}, method="POST")
    try:
        urllib.request.urlopen(req, timeout=15).read()
        return True
    except Exception as exc:
        app.logger.warning("Email delivery failed: %s", exc)
        return False

def ask_gemini(message, verified_context=""):
    """Optional Gemini API. College records must be fetched locally, never guessed."""
    key = os.environ.get("GEMINI_API_KEY")
    if not key:
        return None
    model = os.environ.get("GEMINI_MODEL", "gemini-2.5-flash")
    prompt = ("You are a helpful college helpdesk assistant. Answer clearly and concisely. "
        "Never invent college-specific dates, fees, policies, student records or links. "
        "Use only the verified public college context below for institution-specific claims. "
        "If the context does not answer the question, say to confirm with the college office. "
        "Do not ask for passwords, OTPs, PINs or sensitive identity information.\n\n"
        "VERIFIED PUBLIC COLLEGE CONTEXT (may be empty):\n" + verified_context[:12000] +
        "\n\nStudent question: " + message)
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={key}"
    body = json.dumps({"contents": [{"parts": [{"text": prompt}]}]}).encode()
    req = urllib.request.Request(url, data=body, headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=25) as response:
            result = json.loads(response.read().decode())
        return result["candidates"][0]["content"]["parts"][0]["text"].strip()
    except Exception as exc:
        app.logger.warning("Gemini request failed: %s", exc)
        return None

@app.route("/student/register", methods=["GET", "POST"])
def student_register():
    if request.method == "POST":
        sid = request.form.get("student_id", "").strip().upper()
        password = request.form.get("password", "")
        if len(password) < 10:
            flash("Use a password with at least 10 characters.", "error")
            return redirect(url_for("student_register"))
        conn = get_db()
        student = conn.execute("SELECT * FROM students WHERE student_id=?", (sid,)).fetchone()
        if not student:
            conn.close(); flash("Student ID was not found. Contact the college office.", "error")
            return redirect(url_for("student_register"))
        try:
            conn.execute("INSERT INTO student_accounts(student_id,password_hash) VALUES (?,?)", (sid, generate_password_hash(password)))
            conn.commit()
            send_email(student["email"], "Student portal account created", f"<p>Your student portal account for {sid} was created.</p>")
            flash("Account created. You can now sign in.", "success")
            return redirect(url_for("student_login"))
        except sqlite3.IntegrityError:
            flash("An account already exists for this Student ID.", "error")
        finally:
            conn.close()
    return render_template("student_auth.html", mode="register")

@app.route("/student/login", methods=["GET", "POST"])
def student_login():
    if request.method == "POST":
        sid = request.form.get("student_id", "").strip().upper()
        conn = get_db(); account = conn.execute("SELECT * FROM student_accounts WHERE student_id=?", (sid,)).fetchone(); conn.close()
        if account and check_password_hash(account["password_hash"], request.form.get("password", "")):
            session.clear(); session["student_id"] = sid
            return redirect(url_for("student_portal"))
        flash("Invalid Student ID or password. Register first if this is your first login.", "error")
    return render_template("student_auth.html", mode="login")

@app.route("/student/forgot-password", methods=["GET", "POST"])
def student_forgot_password():
    if request.method == "POST":
        sid=request.form.get("student_id", "").strip().upper(); conn=get_db()
        row=conn.execute("SELECT s.email FROM students s JOIN student_accounts a ON a.student_id=s.student_id WHERE s.student_id=?",(sid,)).fetchone(); conn.close()
        # Always show the same response to avoid revealing whether an account/email exists.
        if row and row["email"]:
            serializer=URLSafeTimedSerializer(app.secret_key)
            token=serializer.dumps(sid, salt="student-password-reset")
            link=url_for("student_reset_password", token=token, _external=True)
            send_email(row["email"], "Student portal password reset", f"<p>Use this link within 30 minutes to reset your password:</p><p><a href='{link}'>Reset password</a></p><p>If you did not request this, ignore this email.</p>")
        flash("If the Student ID has a registered email, a reset link has been sent.", "success")
        return redirect(url_for("student_login"))
    return render_template("student_reset.html", token=None)

@app.route("/student/reset-password/<token>", methods=["GET", "POST"])
def student_reset_password(token):
    serializer=URLSafeTimedSerializer(app.secret_key)
    try: sid=serializer.loads(token, salt="student-password-reset", max_age=1800)
    except (BadSignature, SignatureExpired):
        flash("This reset link is invalid or expired. Request a new one.", "error"); return redirect(url_for("student_forgot_password"))
    if request.method == "POST":
        password=request.form.get("password", "")
        if len(password)<10:
            flash("Use a password with at least 10 characters.", "error")
        else:
            conn=get_db(); conn.execute("UPDATE student_accounts SET password_hash=? WHERE student_id=?",(generate_password_hash(password),sid)); conn.commit(); conn.close()
            flash("Password updated. Please sign in.", "success"); return redirect(url_for("student_login"))
    return render_template("student_reset.html", token=token)

@app.route("/student/portal")
@student_required
def student_portal():
    sid = session["student_id"]; conn = get_db()
    student = conn.execute("SELECT * FROM students WHERE student_id=?", (sid,)).fetchone()
    attendance = conn.execute("SELECT status, COUNT(*) AS n FROM attendance WHERE student_id=? GROUP BY status", (sid,)).fetchall()
    results = conn.execute("SELECT * FROM results WHERE student_id=? ORDER BY semester,subject", (sid,)).fetchall()
    notices = conn.execute("SELECT * FROM notices WHERE expires_on IS NULL OR expires_on>=date('now') ORDER BY id DESC LIMIT 10").fetchall()
    assignments = conn.execute("SELECT * FROM assignments WHERE course IS NULL OR course='' OR course=? ORDER BY id DESC", (student["course"],)).fetchall()
    complaints = conn.execute("SELECT * FROM complaints WHERE student_id=? ORDER BY id DESC", (sid,)).fetchall()
    notifications = conn.execute("SELECT * FROM notifications WHERE student_id IS NULL OR student_id=? ORDER BY id DESC LIMIT 10", (sid,)).fetchall()
    conn.close()
    counts = {r["status"]: r["n"] for r in attendance}; total = sum(counts.values())
    percent = round(counts.get("Present",0) * 100 / total, 1) if total else 0
    return render_template("student_portal.html", student=student, attendance=counts, attendance_total=total,
        attendance_percent=percent, results=results, notices=notices, assignments=assignments,
        complaints=complaints, notifications=notifications)

@app.route("/student/complaint", methods=["POST"])
@student_required
def submit_complaint():
    subject = request.form.get("subject", "").strip(); message = request.form.get("message", "").strip()
    if not subject or not message or len(message) > 4000:
        flash("Enter a subject and message (maximum 4,000 characters).", "error")
    else:
        conn=get_db(); conn.execute("INSERT INTO complaints(student_id,subject,message) VALUES (?,?,?)", (session["student_id"],subject,message)); conn.commit(); conn.close()
        flash("Your complaint has been submitted.", "success")
    return redirect(url_for("student_portal"))

@app.route("/student/logout")
def student_logout():
    session.clear(); return redirect(url_for("index"))

@app.route("/admin/notice", methods=["POST"])
@admin_required
def admin_notice():
    title=request.form.get("title","").strip(); body=request.form.get("body","").strip(); expires=request.form.get("expires_on") or None
    if title and body:
        conn=get_db(); conn.execute("INSERT INTO notices(title,body,expires_on) VALUES (?,?,?)",(title,body,expires)); conn.execute("INSERT INTO notifications(student_id,title,body) VALUES (NULL,?,?)",(title,body)); conn.commit(); conn.close()
        flash("Notice published.","success")
    else: flash("Notice title and message are required.","error")
    return redirect(url_for("dashboard"))

@app.route("/admin/attendance", methods=["POST"])
@admin_required
def admin_attendance():
    sid=request.form.get("student_id","").strip().upper(); day=request.form.get("attendance_date") or datetime.now().strftime("%Y-%m-%d"); status=request.form.get("status","Present")
    conn=get_db(); exists=conn.execute("SELECT 1 FROM students WHERE student_id=?",(sid,)).fetchone()
    if exists and status in {"Present","Absent","Late"}:
        conn.execute("INSERT INTO attendance(student_id,attendance_date,subject,status) VALUES (?,?,?,?)",(sid,day,request.form.get("subject",""),status)); conn.commit(); flash("Attendance saved.","success")
    else: flash("Check Student ID and attendance status.","error")
    conn.close(); return redirect(url_for("dashboard"))

@app.route("/admin/result", methods=["POST"])
@admin_required
def admin_result():
    sid=request.form.get("student_id","").strip().upper(); subject=request.form.get("subject","").strip(); semester=request.form.get("semester","").strip()
    try:
        marks=float(request.form.get("marks")); maximum=float(request.form.get("max_marks",100))
        if not subject or not semester or marks<0 or maximum<=0 or marks>maximum: raise ValueError()
        conn=get_db(); conn.execute("INSERT INTO results(student_id,semester,subject,marks,max_marks) SELECT ?,?,?,?,? WHERE EXISTS(SELECT 1 FROM students WHERE student_id=?)",(sid,semester,subject,marks,maximum,sid)); conn.commit();
        if conn.total_changes: flash("Result saved.","success")
        else: flash("Student ID not found.","error")
        conn.close()
    except (ValueError, TypeError): flash("Enter valid result details and marks.","error")
    return redirect(url_for("dashboard"))

@app.route("/admin/complaint/<int:complaint_id>", methods=["POST"])
@admin_required
def update_complaint(complaint_id):
    status=request.form.get("status","Submitted")
    if status not in {"Submitted","In Progress","Resolved","Rejected"}: abort(400)
    conn=get_db(); conn.execute("UPDATE complaints SET status=? WHERE id=?",(status,complaint_id)); conn.commit(); conn.close()
    flash("Complaint status updated.","success"); return redirect(url_for("dashboard"))

@app.route("/admin/assignment", methods=["POST"])
@admin_required
def admin_assignment():
    title=request.form.get("title","").strip(); file=request.files.get("file"); filename=None
    if file and file.filename:
        if not allowed_file(file.filename): flash("Unsupported file type.","error"); return redirect(url_for("dashboard"))
        filename=f"{datetime.now().strftime('%Y%m%d%H%M%S%f')}_{secure_filename(file.filename)}"; file.save(os.path.join(UPLOAD_DIR,filename))
    if title:
        conn=get_db(); conn.execute("INSERT INTO assignments(title,description,course,due_date,filename) VALUES (?,?,?,?,?)",(title,request.form.get("description",""),request.form.get("course",""),request.form.get("due_date") or None,filename)); conn.commit(); conn.close(); flash("Assignment published.","success")
    else: flash("Assignment title is required.","error")
    return redirect(url_for("dashboard"))

@app.route("/uploads/<path:filename>")
@student_required
def download_assignment(filename):
    from flask import send_from_directory
    conn=get_db(); assignment=conn.execute("SELECT course FROM assignments WHERE filename=?",(filename,)).fetchone(); student=conn.execute("SELECT course FROM students WHERE student_id=?",(session["student_id"],)).fetchone(); conn.close()
    if not assignment or (assignment["course"] and assignment["course"] != student["course"]): abort(404)
    return send_from_directory(UPLOAD_DIR, filename, as_attachment=True)

@app.route("/weather")
def weather():
    """Open-Meteo demonstration endpoint. Uses coordinates supplied as query parameters."""
    try:
        lat=float(request.args.get("lat", "19.0760")); lon=float(request.args.get("lon", "72.8777"))
        if not (-90<=lat<=90 and -180<=lon<=180): raise ValueError()
        url=f"https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}&current=temperature_2m,relative_humidity_2m,precipitation,weather_code&timezone=auto"
        with urllib.request.urlopen(url,timeout=12) as r: data=json.loads(r.read().decode())
        return jsonify(data)
    except Exception: return jsonify({"error":"Weather service unavailable or invalid coordinates."}), 502


@app.route("/health")
def health():
    return jsonify({"status":"ok","app":"Smart Student Helpdesk"})

init_db()

if __name__ == "__main__":
    app.run(debug=os.environ.get("FLASK_DEBUG", "0") == "1")
