"""Smoke tests. Run: python -m unittest discover -s tests"""
import os
import tempfile
import unittest

import app as helpdesk

class HelpdeskSmokeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.old_db = helpdesk.DB_PATH
        helpdesk.DB_PATH = os.path.join(self.tmp.name, "test.db")
        helpdesk.init_db()
        self.client = helpdesk.app.test_client()
        helpdesk.app.config.update(TESTING=True, SECRET_KEY="test-secret")

    def tearDown(self):
        helpdesk.DB_PATH = self.old_db
        self.tmp.cleanup()

    def test_public_pages(self):
        self.assertEqual(self.client.get("/").status_code, 200)
        self.assertEqual(self.client.get("/health").json["status"], "ok")

    def test_student_registration_and_portal(self):
        response = self.client.post("/student/register", data={"student_id":"STU1001", "password":"A-long-test-password"}, follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        response = self.client.post("/student/login", data={"student_id":"STU1001", "password":"A-long-test-password"}, follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Attendance", response.data)

    def test_staff_can_publish_notice(self):
        self.client.post("/login", data={"username":"admin", "password":"admin123"})
        response = self.client.post("/admin/notice", data={"title":"Test", "body":"Test notice"}, follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Notice published", response.data)

if __name__ == "__main__":
    unittest.main()
