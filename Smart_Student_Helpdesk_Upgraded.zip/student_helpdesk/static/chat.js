document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("chatForm");
  const input = document.getElementById("chatInput");
  const messages = document.getElementById("chatMessages");
  if (form && input && messages) {
    function addMessage(text, who) {
      const div = document.createElement("div");
      div.className = "message " + who;
      div.textContent = text;
      messages.appendChild(div);
      messages.scrollTop = messages.scrollHeight;
    }
    async function send(text) {
      if (!text.trim()) return;
      addMessage(text, "user");
      input.value = "";
      try {
        const response = await fetch("/api/chat", {
          method: "POST", headers: {"Content-Type":"application/json"},
          body: JSON.stringify({message:text})
        });
        const data = await response.json();
        addMessage(data.reply, "bot");
      } catch (e) {
        addMessage("Sorry, I couldn't connect. Please try again.", "bot");
      }
    }
    form.addEventListener("submit", e => { e.preventDefault(); send(input.value); });
    document.querySelectorAll("[data-prompt]").forEach(btn =>
      btn.addEventListener("click", () => send(btn.dataset.prompt))
    );
  }
  const search = document.getElementById("studentSearch");
  if (search) search.addEventListener("input", () => {
    const term = search.value.toLowerCase();
    document.querySelectorAll("#studentRows tr").forEach(row => {
      row.style.display = row.dataset.search.includes(term) ? "" : "none";
    });
  });
});
